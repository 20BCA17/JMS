      <footer class="py-4 mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Jewellery Shop Management System</div>
                            
                        </div>
                    </div>
                </footer>

<style>
    .links:hover{
       background-color: #d8d8d8;
       text-decoration: none;
    }

   
</style>
<header id="header">
    
        <div class="container">
            <strong><a href="../index.php" style="color:#737375; text-decoration:none;">Jewellery  Management System</a></strong>
        
        </div>
        <!-- / container -->
    </header>
    <!-- / header -->

    <nav id="menu">
        <div class="container">
            <div class="trigger"></div>
            <ul>
                <li class="links"><a href="../index.php" style="text-decoration: none;">Home</a></li>
                 <li class="links"><a href="../about.php" style="text-decoration: none;">About Us</a></li>
                  <li class="links"><a href="../products.php" style="text-decoration: none;">Products</a></li>
                <li class="links"><a href="../category.php" style="text-decoration: none;">Category</a></li>
               
                <li class="links"><a href="../contact.php"  style="text-decoration: none;">Contact Us</a></li>
              
                <li class="links"><a href="../signup.php"  style="text-decoration: none;">Register</a></li>
                <li class="links"><a href="../login.php"  style="text-decoration: none;">Login</a></li>
                <li class="links"><a href="./index.php"  style="text-decoration: none;">Admin Login</a></li>

            </ul>
        </div>
        <!-- / container -->
    </nav>
    <!-- / navigation -->